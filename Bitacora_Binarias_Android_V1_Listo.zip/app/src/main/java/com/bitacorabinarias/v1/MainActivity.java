package com.bitacorabinarias.v1;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<String> historial = new ArrayList<>();
    SharedPreferences prefs;
    TextView saldo, stats;

    int blue = Color.rgb(21,101,192);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("datos",0);
        saldo=new TextView(this);
        historial.addAll(prefs.getStringSet("hist", new LinkedHashSet<String>()));
        mostrarInicio();
    }

    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(24,18,24,18); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    void base(String titulo){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        TextView bar=tv(titulo,22); bar.setTextColor(Color.WHITE); bar.setBackgroundColor(blue);
        root.addView(bar,new LinearLayout.LayoutParams(-1,70));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc=new ScrollView(this); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);
        String[] ns={"Inicio","Operar","Historial","Estadísticas","Ajustes"};
        for(String n:ns){Button b=btn(n); b.setOnClickListener(v->{
            if(n.equals("Inicio")) mostrarInicio(); else if(n.equals("Operar")) mostrarOperar();
            else if(n.equals("Historial")) mostrarHistorial(); else if(n.equals("Estadísticas")) mostrarStats(); else mostrarAjustes();
        }); nav.addView(b,new LinearLayout.LayoutParams(0,70,1));}
        root.addView(nav); setContentView(root);
    }

    void mostrarInicio(){
        base("Bitácora Binarias V1");
        content.addView(tv("Panel principal",26));
        content.addView(tv("Registra tus operaciones y analiza tu disciplina.",16));
        Button op=btn("＋ Registrar operación"); op.setOnClickListener(v->mostrarOperar()); content.addView(op);
        String s=prefs.getString("saldo","0");
        content.addView(tv("Saldo registrado: $"+s,20));
        content.addView(tv("Operaciones: "+historial.size(),18));
    }

    EditText campo(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(24,8,24,8); content.addView(e); return e; }

    void mostrarOperar(){
        base("Nueva operación");
        content.addView(tv("Datos de la operación",24));
        EditText activo=campo("Activo (ej. EUR/USD)");
        EditText monto=campo("Monto ($)");
        EditText payout=campo("Payout (%)");
        EditText expir=campo("Expiración / temporalidad");
        EditText estrategia=campo("Estrategia");
        EditText sr=campo("Soporte / Resistencia");
        EditText ema=campo("EMA");
        EditText vela=campo("Patrón de vela");
        EditText emocion=campo("Emoción / disciplina");
        Spinner direccion=new Spinner(this);
        direccion.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"CALL","PUT"}));
        content.addView(direccion);
        Spinner resultado=new Spinner(this);
        resultado.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"WIN","LOSS","EMPATE"}));
        content.addView(resultado);
        Button guardar=btn("Guardar operación");
        guardar.setOnClickListener(v->{
            String r=activo.getText().toString()+" | "+direccion.getSelectedItem()+" | $"+monto.getText()+" | "+resultado.getSelectedItem()
                +" | "+estrategia.getText()+" | "+vela.getText();
            historial.add(r);
            prefs.edit().putStringSet("hist",new LinkedHashSet<>(historial)).apply();
            Toast.makeText(this,"Operación guardada",Toast.LENGTH_SHORT).show();
            mostrarHistorial();
        });
        content.addView(guardar);
    }

    void mostrarHistorial(){
        base("Historial");
        if(historial.isEmpty()) content.addView(tv("No hay operaciones registradas.",18));
        else for(int i=0;i<historial.size();i++) content.addView(tv((i+1)+". "+historial.get(i),16));
        Button borrar=btn("Borrar historial");
        borrar.setOnClickListener(v->{historial.clear();prefs.edit().remove("hist").apply();mostrarHistorial();});
        content.addView(borrar);
    }

    void mostrarStats(){
        base("Estadísticas");
        int w=0,l=0;
        for(String x:historial){ if(x.contains("WIN"))w++; if(x.contains("LOSS"))l++; }
        int total=w+l; double rate=total==0?0:(w*100.0/total);
        content.addView(tv("Operaciones: "+historial.size(),20));
        content.addView(tv("Ganadas: "+w,18));
        content.addView(tv("Perdidas: "+l,18));
        content.addView(tv(String.format(Locale.US,"Win rate: %.1f%%",rate),22));
        content.addView(tv("Consejo: usa las estadísticas para evaluar tu disciplina, no para garantizar resultados.",16));
    }

    void mostrarAjustes(){
        base("Ajustes");
        content.addView(tv("Configuración",24));
        EditText e=campo("Saldo inicial");
        e.setText(prefs.getString("saldo",""));
        Button b=btn("Guardar saldo");
        b.setOnClickListener(v->{prefs.edit().putString("saldo",e.getText().toString()).apply();Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();});
        content.addView(b);
        content.addView(tv("Versión 1.0 • Datos guardados localmente en el teléfono.",15));
    }
}
